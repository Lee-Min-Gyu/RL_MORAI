"""ROS communication utilities."""
